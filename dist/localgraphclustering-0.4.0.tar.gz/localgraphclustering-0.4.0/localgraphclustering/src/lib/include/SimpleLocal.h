#ifndef SIMPLELOCAL_H
#define SIMPLELOCAL_H

#include <utility>
#include <unordered_map>

using namespace std;

#include "../SimpleLocal.cpp"
#endif
